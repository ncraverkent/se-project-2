var indexSectionsWithContent =
{
  0: "abcdefghlmoprstwy",
  1: "abcdefglprstw",
  2: "abcdefghloprst",
  3: "dmy",
  4: "lt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Pages"
};

